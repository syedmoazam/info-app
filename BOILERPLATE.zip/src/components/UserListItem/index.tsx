import * as  React from 'react'

const UserListItem = () => {
  return (
    <div>UserListItem</div>
  )
}

export default UserListItem